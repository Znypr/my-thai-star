package com.devonfw.application.mtsj.general.common.api;

/**
 * A marker interface for REST services. REST service interfaces of components should extend this interface.
 *
 */
public interface RestService {

}
