package com.devonfw.application.mtsj.general.common.api.constants;

/**
 * Contains constants for the keys of all
 * {@link com.devonfw.module.security.common.api.accesscontrol.AccessControlPermission}s.
 */
public abstract class PermissionConstants {

  // put your permission names from access-control-schema.xml as constants here (or generate with cobigen)

}
