package com.devonfw.application.mtsj.usermanagement.service.impl;

/**
 * TODO akkus This type ...
 *
 */
public class ResetTokenRestServiceImpl {

}
