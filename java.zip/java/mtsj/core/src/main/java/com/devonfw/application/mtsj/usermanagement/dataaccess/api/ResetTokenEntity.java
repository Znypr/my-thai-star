package com.devonfw.application.mtsj.usermanagement.dataaccess.api;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.devonfw.application.mtsj.general.dataaccess.api.ApplicationPersistenceEntity;

/**
 * TODO akkus This type ...
 *
 */

@Entity
@Table(name = "ResetToken")
public class ResetTokenEntity extends ApplicationPersistenceEntity {

  private Long userId;

  private Date dateExpire;

  private String token;

  private boolean flag;

  public Long getUserId() {

    return this.userId;
  }

  public Date getDateExpire() {

    return this.dateExpire;
  }

  public String getToken() {

    return this.token;
  }

  public boolean getFlag() {

    return this.flag;
  }

}
