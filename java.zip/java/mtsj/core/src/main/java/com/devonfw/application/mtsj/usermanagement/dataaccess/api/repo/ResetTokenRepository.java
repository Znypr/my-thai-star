package com.devonfw.application.mtsj.usermanagement.dataaccess.api.repo;

import org.springframework.data.domain.Page;

import com.devonfw.application.mtsj.usermanagement.common.api.to.ResetTokenSearchCriteriaTo;
import com.devonfw.application.mtsj.usermanagement.dataaccess.api.ResetTokenEntity;
import com.devonfw.module.jpa.dataaccess.api.QueryUtil;
import com.devonfw.module.jpa.dataaccess.api.data.DefaultRepository;
import com.querydsl.core.alias.Alias;
import com.querydsl.jpa.impl.JPAQuery;

/**
 * TODO akkus This type ...
 *
 */
public interface ResetTokenRepository extends DefaultRepository<ResetTokenEntity> {

  default Page<ResetTokenEntity> findResetToken(ResetTokenSearchCriteriaTo criteria) {

    ResetTokenEntity alias = newDslAlias();
    JPAQuery<ResetTokenEntity> query = newDslQuery(alias);

    String token = criteria.getToken();
    if ((token != null) && alias.getToken() != null) {
      query.where(Alias.$(alias.getToken()).eq(token));
    }

    return QueryUtil.get().findPaginated(criteria.getPageable(), query, false);
  }

}
