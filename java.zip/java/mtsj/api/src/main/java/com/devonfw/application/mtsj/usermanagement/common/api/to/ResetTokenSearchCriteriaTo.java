package com.devonfw.application.mtsj.usermanagement.common.api.to;

import java.util.Date;

import com.devonfw.application.mtsj.general.common.api.to.AbstractSearchCriteriaTo;

/**
 * TODO akkus This type ...
 *
 */
public class ResetTokenSearchCriteriaTo extends AbstractSearchCriteriaTo {

  private static final long serialVersionUID = 1L;

  private Long userId;

  private Date dateExpire;

  private String token;

  private boolean flag;

  /**
   * The constructor.
   */
  public ResetTokenSearchCriteriaTo() {

    super();
  }

  public String getToken() {

    return this.token;
  }

}
