package ga.codehub.tools.exceptions;

public class Different extends Exception {
}
