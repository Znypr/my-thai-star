package ga.codehub.entity.menue;

public class Dish {
    public String modificationCounter;
    public String id;
    public String name;
    public String description;
    public String price;
    public String imageId;
}