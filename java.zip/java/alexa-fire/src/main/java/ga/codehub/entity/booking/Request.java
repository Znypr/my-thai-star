package ga.codehub.entity.booking;

public class Request {
    public Booking booking;
}