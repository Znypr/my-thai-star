package ga.codehub.entity.booking;

public class Booking {
    public String bookingDate;
    public String name;
    public String email;
    public String assistants;
}