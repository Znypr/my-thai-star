package ga.codehub.tools.exceptions;

public class TooMuchRequest extends Exception {
}
