package ga.codehub.entity.menue;

public class Image {
    public String modificationCounter;
    public String id;
    public String name;
    public String content;
    public String contentType;
    public String mimeType;
}