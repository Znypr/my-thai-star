package ga.codehub.tools.exceptions;

public class NotFound extends Exception {
}
