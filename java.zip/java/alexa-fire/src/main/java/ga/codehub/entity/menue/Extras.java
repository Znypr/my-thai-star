package ga.codehub.entity.menue;

public class Extras {
    public String modificationCounter;
    public String id;
    public String name;
    public String description;
    public String price;
}