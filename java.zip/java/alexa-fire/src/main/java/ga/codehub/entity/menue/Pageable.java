package ga.codehub.entity.menue;

public class Pageable {
    public String pageNumber;
    public String pageSize;
}