package ga.codehub.tools.exceptions;

public class EndOfEntries extends Exception {
}
