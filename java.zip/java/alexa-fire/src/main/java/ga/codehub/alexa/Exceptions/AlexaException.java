package ga.codehub.alexa.Exceptions;

public class AlexaException extends Exception {
}
