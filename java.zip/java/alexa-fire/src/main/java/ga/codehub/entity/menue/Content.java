package ga.codehub.entity.menue;

public class Content {
    public Dish dish;
    public Image image;
    public Extras[] extras;
    public Categories[] categories;
}