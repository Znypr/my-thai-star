// Roles
export interface Role {
  name: string;
  permission: number;
}
