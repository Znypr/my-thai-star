import { Directive } from '@angular/core';

@Directive({
  // tslint:disable-next-line: directive-selector
  selector: '[webview]',
})
export class WebviewDirective {}
