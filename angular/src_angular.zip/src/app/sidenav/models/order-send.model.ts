export interface OrderSend {
  orderSent: boolean;
}
