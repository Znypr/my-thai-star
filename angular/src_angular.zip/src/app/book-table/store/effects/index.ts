import { BookTableEffects } from './book-table.effects';
export const effects: any[] = [BookTableEffects];
export * from './book-table.effects';
