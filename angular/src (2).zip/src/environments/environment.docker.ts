export const environment: {
  production: boolean;
  loadExternalConfig: boolean;
} = { production: true, loadExternalConfig: true };
