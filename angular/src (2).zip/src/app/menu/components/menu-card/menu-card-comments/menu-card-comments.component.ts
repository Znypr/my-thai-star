import { Component } from '@angular/core';

@Component({
  selector: 'app-own-menu-card-comments',
  templateUrl: './menu-card-comments.component.html',
  styleUrls: ['./menu-card-comments.component.scss'],
})
export class MenuCardCommentsComponent {}
