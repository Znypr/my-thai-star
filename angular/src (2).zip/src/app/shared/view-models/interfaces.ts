import { Pageable } from '../backend-models/interfaces';

// DISHES
export interface DishView {
  dish: PlateView;
  image: { content: string };
  extras: ExtraView[];
  likes: number;
  isfav: boolean;
  categories?: { id: string }[];
}

export interface PlateView {
  id: number;
  name: string;
  description: string;
  price: number;
}

export interface ExtraView {
  id: number;
  name: string;
  price: number;
  selected?: boolean;
}

export interface DishResponse {
  pageable: Pageable;
  content: DishView;
}

// BOOKING
export interface ReservationView {
  booking: BookingView;
  invitedGuests?: FriendsInvite[];
}

export interface BookingView {
  bookingDate: string;
  name: string;
  email: string;
  assistants?: number;
  tableId?: number;
  bookingToken?: number;
  creationDate?: string;
}

export interface FriendsInvite {
  email: string;
  accepted: boolean;
}
export interface OrderDishView {
  dish: {
    id: number;
    name: string;
    price: number;
  };
}

export interface OrderView {
  dish: {
    id: number;
    name: string;
    price: number;
  };
  orderLine: {
    amount: number;
    comment: string;
  };
  extras: ExtraView[];
}

// inserted for admin-cockpit
// TODO: ADD IMPORTANT DATA
export interface UserView{
  user: {
    id: number;
    username: string;
    email: string;
    idRole: number;
  };
}


export interface UserListView {
  user: UserView[];
}

export interface OrderViewResult {
  dish: {
    id: number;
    name: string;
    price: number;
  };
  orderLine: {
    amount: number;
    comment: string;
  };
  extras: string;
}

export interface OrderListView {
  orderLines: OrderView[];
  booking: BookingView;
  orderStatus: string;
}

export interface OrderDishListView {
  orderLines: OrderDishView[];
  booking: BookingView;
}

// Interface to recieve responeses from the server using httpclient for get users
//added for admin-cockpit
export interface UserResponse {
  pageable: Pageable;
  content: UserListView;
}

// Interface to recieve responeses from the server using httpclient for getReservations
export interface BookingResponse {
  pageable: Pageable;
  content: ReservationView;
}

// Interface to receive responses from the server using httpclient to get orders
export interface OrderResponse {
  pageable: Pageable;
  content: OrderListView;
}

// Interface to receive responses from the server using httpclient to get OrderDishResponse
export interface OrderDishResponse {
  pageable: Pageable;
  result: OrderDishListView;
}

// Interface to receive responses from the server using httpclient for email invitations
export interface InvitationResponse {
  id: number;
  modificationCounter: number;
  accepted: boolean;
  guestToken: string;
  modificationDate: any;
  revision: any;
}

// Not sure if this should just use bookingview interface, just in case Im creating a new interface that extends booking view
export interface BookingTableResponse extends BookingView {
  bookingType: string;
  cancelled: false;
  comment: string;
  expeditionDate: string;
  id: number;
  modificationCounter: number;
  orderId: number;
  revision: any;
  userId: number;
}

// Interface to receive responses from the server using httpclient for SaveOrders
export interface SaveOrderResponse {
  bookingId: number;
  bokingToken: string;
  hostId: number;
  id: number;
  invitedGuestId: number;
  modificationCounter: number;
  revision: any;
}

// Roles
export interface Role {
  name: string;
  permission: number;
}

// Interface for prediction data for a dish
export interface OrdersData {
  dates?: Date[];
  holidays?: string[];
  weather?: number[];
  dishes: DishOrdersData[];
}

// Interface for order of a dish
export interface DishOrdersData {
  id: number;
  // name of the dish
  name: string;
  // count of orders of the dish, that have been ordered in certain period
  orders: number[];
}

// Interface for Cluster
export interface Cluster {
  id: number;
  dishId: number;
  dishName: string;
  amount: number;
  polygon: {};
  x: string;
  y: string;
}
export interface ClustersData {
  data: Cluster[];
  id: number;
  modificationCounter: number;
}

// Interface for Two-Factor Authentication
export interface TwoFactorResponse {
  twoFactorStatus?: boolean;
  base64QrCode?: string;
  secret?: string;
}
