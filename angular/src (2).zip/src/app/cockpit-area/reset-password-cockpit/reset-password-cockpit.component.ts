import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset-password-cockpit',
  templateUrl: './reset-password-cockpit.component.html',
  styleUrls: ['./reset-password-cockpit.component.scss']
})
export class ResetPasswordCockpitComponent implements OnInit {
  hide = true;

  constructor(
    // private adminCockpitService: AdminCockpitService
  ) { }

  // changePassword(userId: number) {
  //   let path = this.changePasswordRestPath;
  //   this.adminCockpitService.restServiceRoot$.pipe(
  //     exhaustMap((restServiceRoot) =>
  //       this.http.post(`${restServiceRoot}${path}`, {})
  // }

  ngOnInit(): void {
  }

}
