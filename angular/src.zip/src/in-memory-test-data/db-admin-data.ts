export const userData: any = {
  content: [{
    user: {
      modificationCounter: 1,
      id: 1,
      username: 'waiter',
      email: 'waiter@mail.com',
      twoFactorStatus: false,
      userRoleId: 1,
    }
  }]
}
