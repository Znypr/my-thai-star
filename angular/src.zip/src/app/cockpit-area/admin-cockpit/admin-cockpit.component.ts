import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-cockpit',
  templateUrl: './admin-cockpit.component.html',
  styleUrls: ['./admin-cockpit.component.scss']
})
export class AdminCockpitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
