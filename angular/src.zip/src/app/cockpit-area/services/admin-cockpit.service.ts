import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { exhaustMap } from 'rxjs/operators';
import { ConfigService } from '../../core/config/config.service';


@Injectable({
  providedIn: 'root'
})
export class AdminCockpitService {
  private readonly getUsers: string='ordermanagement/v1/order/search';
  private readonly restServiceRoot$: Observable<
    string
  > = this.config.getRestServiceRoot();
  constructor(
    private http: HttpClient,
    private config: ConfigService,
  ) { }

}
