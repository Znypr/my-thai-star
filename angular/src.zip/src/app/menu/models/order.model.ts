import { OrderView } from '../../shared/view-models/interfaces';

export interface Order {
  id: string;
  details: OrderView;
}
