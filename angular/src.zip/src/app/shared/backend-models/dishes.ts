// DISHES
export class ExtraInfo {
  id: number;
  name: string;
  price: number;
  selected: boolean;
}
