import { SendOrderEffects } from './send-order.effects';
export const effects: any[] = [SendOrderEffects];
export * from './send-order.effects';
