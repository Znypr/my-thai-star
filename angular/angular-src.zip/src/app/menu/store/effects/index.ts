import { MenuEffects } from './menu.effects';
export const effects: any[] = [MenuEffects];
export * from './menu.effects';
