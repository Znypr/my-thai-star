import { ConfigEffects } from './config.effects';
export const effects: any[] = [ConfigEffects];
export * from './config.effects';
