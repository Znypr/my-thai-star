import { Component } from '@angular/core';

@Component({
  selector: 'app-public-not-supported',
  templateUrl: './not-supported.component.html',
  styleUrls: ['./not-supported.component.scss'],
})
export class NotSupportedComponent {}
