import { AuthEffects } from './auth.effects';
export const effects: any[] = [AuthEffects];
export * from './auth.effects';
